def valBBget(x,y):
    return(x+y)